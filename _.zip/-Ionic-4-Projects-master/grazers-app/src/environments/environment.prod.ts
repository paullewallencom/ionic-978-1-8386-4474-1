export const environment = {
    production: true,
    firebaseConfig: {
        apiKey: 'AIzaSyDfDZPcohdCfIxbGMiyG3lrARBtsKcMEx0',
        databaseURL: 'https://store-locator-app-253613.firebaseio.com',
        storageBucket: 'store-locator-app-253613.appspot.com',
        authDomain: 'store-locator-app-253613.firebaseapp.com',
        messagingSenderId: '790804268669',
        projectId: 'store-locator-app-253613',
        appId: '1:790804268669:web:dd0641963ee061fe321314'
    }
};
